# Trabalho complementar 2 de CGR
  *Paulo roberto Albuquerque*

Observações:
- O arquivo `constants.py` se trata de uma biblioteca local pra cores e valores de iluminação e textura.
- O arquivo `formas_complexas.py` se trata de uma biblioteca retirada da internet para a geração de formas mais complexas, as quais o OpenGL não possui funções prontas, e portanto, não é de minha autoria.