from .banda_dao import BandaDAO
from .disco_dao import DiscoDAO
from .endereco_dao import EnderecoDAO
from .instrumento_dao import InstrumentoDAO
from .musica_dao import MusicaDAO
# from .musica_disco_dao import Musica_DiscoDAO
# from .musico_banda_dao import Musico_BandaDAO
# from .musico_instrumento_dao import Musico_InstrumentoDAO
from .musico_dao import MusicoDAO
from .produtor_dao import ProdutorDAO
