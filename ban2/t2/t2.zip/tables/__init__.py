from .banda import Banda
from .disco import Disco
from .endereco import Endereco
from .instrumento import Instrumento
from .musica import Musica
# from .musica_disco import Musica_Disco
# from .musico_banda import Musico_Banda
# from .musico_instrumento import Musico_Instrumento
from .musico import Musico
from .produtor import Produtor
