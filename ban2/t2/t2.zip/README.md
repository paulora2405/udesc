## Dependencies

Instalar MongoDB e módulo para python:

```sh
$ pip3 install pymongo
```