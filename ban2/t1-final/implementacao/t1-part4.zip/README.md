## Dependencies

```sh
$ sudo apt install python3-dev libpq-dev
$ pip3 install psycopg2
```