import java.io.*;
import java.util.*;
import com.rabbitmq.client.*;

public class Client {
  private final static String queue_name = "Server-RabbitMQ";
  private static String tag = "";
  public static Thread thr = null;
  private static ConnectionFactory factory;
  private static Connection connection;
  private static Channel channel;
  private static Scanner input = new Scanner(System.in);

  public static void main(String[] args) throws Exception {
    factory = new ConnectionFactory();
    factory.setHost("localhost");
    connection = factory.newConnection();
    channel = connection.createChannel();
    System.out.print("Digite sua tag: ");
    tag = input.nextLine();

    System.out.println("Cliente inicializado com sucesso!\nAguardando mensagens...");
    channel.queueDeclare(queue_name, false, false, false, null);

    String header = "##NEW##" + tag;
    channel.basicPublish("", queue_name, null, header.getBytes("UTF-8"));

    int x = 2;
    while (x != 0) {
      if (x == 1) {
        x = 2;
        System.out.println("Digite o nome do arquivo do chat a ser enviado (com a extensão):");
        String path = input.nextLine();
        String message = sendFile(path);
        channel.basicPublish("", queue_name, null, message.getBytes("UTF-8"));
      } else if (x == 2) {
        Consumer consumer = new DefaultConsumer(channel) {
          @Override
          public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body)
              throws IOException {
            String message = new String(body, "UTF-8");
            int index = message.indexOf("##ID##");
            String id = message.substring(0, index);
            message = message.substring(index + 6);
            index = message.indexOf("##TAG##");
            String tagSender = message.substring(0, index);
            message = message.substring(index + 7);
            System.out.println(tagSender + "enviou um chat!");
            receiveFile(tag, tagSender, id, message);
          }
        };
        channel.basicConsume(tag, true, consumer);
      }
      System.out.println("Digite 1 para enviar um chat (0 para sair)");
      x = Integer.parseInt(input.nextLine());
    }
    channel.queueDelete(queue_name);
    channel.close();
    connection.close();
  }

  public static String sendFile(String path) throws Exception {
    try {
      InputStream is = new FileInputStream(path);
      byte[] bytes = new byte[65536];
      is.read(bytes);
      is.close();
      return new String(bytes);
    } catch (Exception e) {
      throw new Exception(e);
    }

  }

  public static void receiveFile(String recvTag, String sendTag, String id, String message) {
    try {
      String path = recvTag + "-client";
      new File(path).mkdir();
      FileWriter fw = new FileWriter(path + "/" + sendTag + "-" + id + ".client");
      fw.write(message);
      fw.close();
    } catch (Exception e) {
      return;
    }
  }
}
